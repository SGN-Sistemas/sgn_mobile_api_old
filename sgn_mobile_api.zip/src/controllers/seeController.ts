import { Request, Response } from 'express'

export class SeeControllers {
  public async notificationPedido (request: Request, response: Response) {
    const { id } = request.params
  }
}
