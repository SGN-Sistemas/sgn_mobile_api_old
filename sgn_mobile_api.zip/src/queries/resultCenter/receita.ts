export const querySelectReceita = (planoContas: string, codigo: string, dataFim: string, dataIni: string) => {
  //      if (parseInt(element.tipo) === 4 || parseInt(element.tipo) === 5 ||
  // parseInt(element.tipo) === 8) {
  return `
    `
}
